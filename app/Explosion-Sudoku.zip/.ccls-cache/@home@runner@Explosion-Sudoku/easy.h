#include <iostream>

class Easy {
  public:
  void easy();
};