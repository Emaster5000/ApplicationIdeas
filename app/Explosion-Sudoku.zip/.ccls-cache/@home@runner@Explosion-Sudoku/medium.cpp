#include "medium.h"
using namespace std;

void Medium::medium() {
  string n1, n2, n3, n4, n5, n6, n7, n8, n9;
  char top[] = "________________________________________\n";
  char line[] = "----------------------------------------\n";
  char line2[] = "========================================\n";
  int medium = rand()%1;
  if (medium == 0) {
    
  }
}