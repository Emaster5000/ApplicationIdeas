#include <iostream>

class Medium {
  public:
  void medium();
};