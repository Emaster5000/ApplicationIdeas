#include <iostream>

class Expert {
  public:
  void expert();
};