#include <iostream>

class Hard {
  public:
  void hard();
};